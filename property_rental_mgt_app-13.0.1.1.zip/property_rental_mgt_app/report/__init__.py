# -*- coding: utf-8 -*-

from . import contract_report
from . import report